
document.addEventListener('DOMContentLoaded', function() {
    new Swiper('.featured-swiper', {
    slidesPerView: 4,
    spaceBetween: 20,
    loop: true,
    autoplay: {
        delay: 2000,
        disableOnInteraction: false,
    },
    navigation: {
        nextEl: '.featured-swiper .swiper-button-next',
        prevEl: '.featured-swiper .swiper-button-prev'
    },
    breakpoints: {
        320: {
        slidesPerView: 1,
        spaceBetween: 15
        },
        576: {
        slidesPerView: 2,
        spaceBetween: 15
        },
        768: {
        slidesPerView: 3,
        spaceBetween: 20
        },
        992: {
        slidesPerView: 4,
        spaceBetween: 20
        }
    }
    });
});

// Theme Toggle
const themeToggle = document.getElementById('themeToggle');
const themeIcon = themeToggle.querySelector('i');

themeToggle.addEventListener('click', () => {
    document.body.classList.toggle('dark-theme');
    
    if (document.body.classList.contains('dark-theme')) {
    themeIcon.classList.remove('fa-moon');
    themeIcon.classList.add('fa-sun');
    } else {
    themeIcon.classList.remove('fa-sun');
    themeIcon.classList.add('fa-moon');
    }
});

// Scroll Animations
const observerOptions = {
    root: null,
    rootMargin: '0px',
    threshold: 0.1
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
    if (entry.isIntersecting) {
        entry.target.classList.add('in-view');
    }
    });
}, observerOptions);

// Observe all animated elements
document.querySelectorAll('.section-header, .product-card, .newsletter').forEach(el => {
    observer.observe(el);
});

// Simulate user login for demo
setTimeout(() => {
    document.querySelector('.auth-buttons').style.display = 'none';
    document.querySelector('.user-account').classList.add('active');
}, 3000);