// Sticky Filter Bar Logic
    const filterBar = document.getElementById('filterBar');
    let lastScrollTop = 0;
    
    window.addEventListener('scroll', () => {
      const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
      
      // Show filter bar when scrolling up
      if (scrollTop > 200 && scrollTop < lastScrollTop) {
        filterBar.classList.add('active');
      } else {
        filterBar.classList.remove('active');
      }
      
      lastScrollTop = scrollTop <= 0 ? 0 : scrollTop;
    });

    // Category Filter Buttons
    const categoryButtons = document.querySelectorAll('.category-btn');
    
    categoryButtons.forEach(button => {
      button.addEventListener('click', () => {
        // Remove active class from all buttons
        categoryButtons.forEach(btn => btn.classList.remove('active'));
        
        // Add active class to clicked button
        button.classList.add('active');
      });
    });

    // Simulate user login for demo
    setTimeout(() => {
      document.querySelector('.auth-buttons').style.display = 'none';
      document.querySelector('.user-account').classList.add('active');
    }, 3000);