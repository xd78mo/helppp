document.addEventListener('DOMContentLoaded', () => {
      const signUpButton = document.getElementById('signUp');
      const signInButton = document.getElementById('signIn');
      const container    = document.getElementById('container');

      signUpButton.addEventListener('click', () => {
        container.classList.add('right-panel-active');
      });
      
      signInButton.addEventListener('click', () => {
        container.classList.remove('right-panel-active');
      });
      
      function setupPasswordToggle(inputId, toggleIconId) {
        const pwdInput   = document.getElementById(inputId);
        const toggleIcon = document.getElementById(toggleIconId);
        if (!pwdInput || !toggleIcon) return;
        toggleIcon.addEventListener('click', () => {
          const isPlain = pwdInput.type === 'text';
          pwdInput.type = isPlain ? 'password' : 'text';
          toggleIcon.classList.toggle('fa-eye');
          toggleIcon.classList.toggle('fa-eye-slash');
        });
      }
      
      setupPasswordToggle('signUpPassword', 'toggleSignUpPassword');
      setupPasswordToggle('signInPassword', 'toggleSignInPassword');
      
      // Form submission
      document.getElementById('signInForm').addEventListener('submit', function(e) {
        e.preventDefault();
        // Simulate login
        alert('Login successful! Redirecting to homepage...');
        setTimeout(() => window.location.href = 'home.html', 1000);
      });
      
      document.getElementById('signUpForm').addEventListener('submit', function(e) {
        e.preventDefault();
        // Simulate registration
        alert('Account created successfully! Redirecting to homepage...');
        setTimeout(() => window.location.href = 'home.html', 1000);
      });
    });